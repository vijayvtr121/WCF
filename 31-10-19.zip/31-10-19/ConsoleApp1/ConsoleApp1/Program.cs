﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
	class Program
	{
		static void Main(string[] args)
		{
			ServiceReference1.Service1Client obj = new ServiceReference1.Service1Client();
			ServiceReference1.Order order = new ServiceReference1.Order();
			ServiceReference1.Customer cust = new ServiceReference1.Customer();
			ServiceReference1.Order_Item item1 = new ServiceReference1.Order_Item();

			cust.CustomerID = 1;
			cust.Name = "Vijay";
			cust.CCNumber = 3875487354737658;
			cust.CVV = 678;
			cust.AmounttoDebit = 4000;

			item1.ItemName = "Tomato gojuu";
			item1.Quantity = 10;
			item1.TotalAmount = 80;

			order.C1 = cust;
			order.Item = item1;

			bool res = obj.CreateOrder(order);
			if (res)
				Console.WriteLine("Order created successfully");
			else
				Console.WriteLine("Order didnt place");

			Console.ReadLine();
		}
		
	}
}
