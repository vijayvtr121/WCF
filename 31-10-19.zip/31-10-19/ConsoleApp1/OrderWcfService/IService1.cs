﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace OrderWcfService
{
	// NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IService1" in both code and config file together.
	[ServiceContract]
	public interface IService1
	{


		[OperationContract]
		bool CreateOrder(Order order);
	}


	[DataContract]
	public class Customer
	{
		int cid;
		string name;
		long ccnumber;
		int cvv;
		int amounttodebit;

		[DataMember]
		public int CustomerID
		{
			get { return cid; }
			set { cid = value; }
		}
		[DataMember]
		public String Name
		{
			get { return name; }
			set { name = value; }
		}
		[DataMember]
		public long CCNumber
		{
			get { return ccnumber; }
			set { ccnumber = value; }
		}
		[DataMember]
		public int CVV
		{
			get { return cvv; }
			set { cvv = value; }
		}
		[DataMember]
		public int AmounttoDebit
		{
			get { return amounttodebit; }
			set { amounttodebit = value; }
		}
	}

		[DataContract]
		public class Order_Item
		{
			string itemname;
			int quantity;
			int totalamount;
			[DataMember]
			public String ItemName
			{
				get { return itemname; }
				set { itemname = value; }
			}
			[DataMember]
			public int Quantity
			{
				get { return quantity; }
				set { quantity = value; }
			}
			[DataMember]
			public int TotalAmount
			{
				get { return totalamount; }
				set { totalamount = value; }
			}

		}

		[DataContract]
		public class Order
		{
			Customer c1;
			Order_Item item;

			[DataMember]
			public Customer C1
			{
				get { return c1; }
				set { c1 = value; }
			}
			[DataMember]
			public Order_Item Item
			{
				get { return item; }
				set { item = value; }
			}
		}
}

