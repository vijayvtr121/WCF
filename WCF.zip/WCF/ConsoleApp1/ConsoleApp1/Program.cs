﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            ServiceReference1.IService1 obj = new ServiceReference1.Service1Client();
            int resultAdd = obj.add(3, 5);
            int mul = obj.mul(3, 5);
            Console.WriteLine("sum is" + resultAdd);
            Console.WriteLine("mul is" + mul);
            Console.ReadLine();

        }
    }
}
