﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using System.Data.SqlClient;
using System.Configuration;

namespace WcfService1
{
	// NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in code, svc and config file together.
	// NOTE: In order to launch WCF Test Client for testing this service, please select Service1.svc or Service1.svc.cs at the Solution Explorer and start debugging.
	public class Service1 : IService1
	{
		public List<Book> GetBooks()
		{
			/*List<Book> bookarray = new List<Book>();
			Book b1 = new Book();
			b1.Id = 1;
			b1.Title = "Magic of blue";
			b1.Author = "vtr";
			b1.Price = 209;

			Book b2 = new Book();
			b2.Id = 2;
			b2.Title = "Magic of red";
			b2.Author = "vtr";
			b2.Price = 1209;
			bookarray.Add(b1);
			bookarray.Add(b2);
			return bookarray;*/
			var Booklist = new List<Book>();
			string connstr = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
			SqlConnection connection = new SqlConnection(connstr);
			SqlCommand command = new SqlCommand("select Id,Title,Author,Price from [Table]; ", connection);
			connection.Open();
			SqlDataReader reader = command.ExecuteReader();
			if(reader.HasRows)
			{
				while(reader.Read())
				{
					Book obj = new Book();
					obj.Id = reader.GetInt32(0);
					obj.Title = reader.GetString(1);
					obj.Author = reader.GetString(2);
					obj.Price = reader.GetDouble(3);
					Booklist.Add(obj);
				}
			}
			reader.Close();
			return Booklist;
		}

		
	}
}
